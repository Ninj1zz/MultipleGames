package main.pong.entity.utils;

public enum Difficulty {
    UNBEATABLE,NORMAL,EASY
}
